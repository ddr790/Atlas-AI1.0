# ATLAS — correção do Google Login

## Problema encontrado
O aplicativo detectava a plataforma Android/Capacitor e usava `signInWithRedirect()` para o Google. Esse fluxo devolvia o usuário para o navegador/host de autenticação, mas o WebView do aplicativo não tinha um retorno OAuth nativo configurado. O resultado era: escolher a conta -> continuar -> erro no navegador -> voltar -> tela de login/loop.

## Correção aplicada
O botão Google agora usa `signInWithPopup()` no JavaScript do app, mantendo o login por e-mail/senha e o Firebase Authentication existentes.

O Firebase documenta `signInWithPopup()` como alternativa ao redirect quando o redirect causa problemas de armazenamento/retorno. Para ambientes híbridos/Cordova, a documentação atual também recomenda um fluxo OAuth compatível com o ambiente em vez de depender do fluxo antigo de redirect.

## Limitação importante
Este arquivo é uma extração do APK, não o projeto-fonte Gradle original. A alteração acima foi feita nos assets WebView. Para gerar um APK instalável assinado, é necessário reconstruir o projeto Android/Capacitor original.

## Firebase
Configuração encontrada no APK:
- projectId: atlas-9f28f
- authDomain: atlas-9f28f.firebaseapp.com
- appId: 1:69441691797:web:ddc0dba7dbdfb977b7fb9c

A configuração Web do Firebase (apiKey/appId etc.) não é um segredo por si só; a proteção deve estar nas regras/provedores do Firebase.
